@push('css_head')
@endpush

@push('js_tail')
<script src="/frontsite/js/lib/jquery-validation/dist/jquery.validate.min.js"></script>
<script src="/frontsite/js/forms-validation-rules.js"></script>
@endpush