const firebase_config = {
	apiKey: "AIzaSyA1pfyOEoSgnb3833rIGQBii3o7knKZJH4",
	authDomain: "sitl-6e7a3.firebaseapp.com",
	databaseURL: "https://sitl-6e7a3.firebaseio.com",
	projectId: "sitl-6e7a3",
	storageBucket: "sitl-6e7a3.appspot.com",
	messagingSenderId: "575820902172"
}
export {firebase_config}