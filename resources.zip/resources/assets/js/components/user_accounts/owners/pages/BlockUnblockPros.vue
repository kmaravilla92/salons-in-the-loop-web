<template>
	<div class="content-container dashboard-owner featured-pro ">
		<div class="inner-title">
			<h3>Block /Unblock Professionals</h3>
		</div>
		<div class="listing-holder block-unb">
			<div class="pro-holder">
				<div class="img-over">
					<div class="img-holder">
						<img src="/frontsite/images/pro1.jpg" alt="">
					</div>
					<div class="onoff-holder">
						<img src="/frontsite/images/online-status.png" alt="">
					</div>
				</div>
				<h3>Jessica Mathew</h3>
				<h5>Nails</h5>
				<p>Square Town, Square City, Colorado - CO, 11010</p>
				<div class="rating-holder">
					<i class="fa fa-star" aria-hidden="true"></i>
					<i class="fa fa-star" aria-hidden="true"></i>
					<i class="fa fa-star" aria-hidden="true"></i>
					<i class="fa fa-star" aria-hidden="true"></i>
					<i class="fa fa-star" aria-hidden="true"></i>
				</div>
				<a href="#" class="btn btn-grey-b">Unblock</a>
			</div>
			<div class="pro-holder">
				<div class="img-over">
					<div class="img-holder">
						<img src="/frontsite/images/pro2.jpg" alt="">
					</div>
					<div class="onoff-holder">
						<img src="/frontsite/images/offline-status.png" alt="">
					</div>
				</div>
				<h3>Jessica Mathew</h3>
				<h5>Nails</h5>
				<p>Square Town, Square City, Colorado - CO, 11010</p>
				<div class="rating-holder">
					<i class="fa fa-star" aria-hidden="true"></i>
					<i class="fa fa-star" aria-hidden="true"></i>
					<i class="fa fa-star" aria-hidden="true"></i>
					<i class="fa fa-star" aria-hidden="true"></i>
					<i class="fa fa-star" aria-hidden="true"></i>
				</div>
				<a href="#" class="btn btn-grey-b">Unblock</a>
			</div>
			<div class="pro-holder">
				<div class="img-over">
					<div class="img-holder">
						<img src="/frontsite/images/pro3.jpg" alt="">
					</div>
					<div class="onoff-holder">
						<img src="/frontsite/images/online-status.png" alt="">
					</div>
				</div>
				<h3>Jessica Mathew</h3>
				<h5>Nails</h5>
				<p>Square Town, Square City, Colorado - CO, 11010</p>
				<div class="rating-holder">
					<i class="fa fa-star" aria-hidden="true"></i>
					<i class="fa fa-star" aria-hidden="true"></i>
					<i class="fa fa-star" aria-hidden="true"></i>
					<i class="fa fa-star" aria-hidden="true"></i>
					<i class="fa fa-star" aria-hidden="true"></i>
				</div>
				<a href="#" class="btn btn-grey-b">Unblock</a>
			</div>


		</div>
		<br><br><br><br><br><br>
		<br><br><br><br><br><br>
		<br><br><br><br><br><br>
		<br><br><br><br><br><br>
	</div>
</template>

<script>
	export default {

	}
</script>