<template>
	<div class="content-container">
		<div class="menu-content">
			<div class="inner-title">
				<h3>What Would you like to do?</h3>
			</div>
			<ul>
				<li>
					<a href="#">
						<div class="img-holder">
							<img src="/frontsite/images/posted-ico.png" alt="">
						</div>

						<p class="ease">My Posted <br> Rentals</p>
					</a>
				</li>
				<li>
					<a href="#">
						<div class="img-holder">
							<img src="/frontsite/images/posted-ico.png" alt="">
						</div>
						<p class="ease">My Posted <br> Help Request</p>
					</a>
				</li>
				<li>
					<a href="#">
						<div class="noti-count ease">
							<p>16</p>
						</div>
						<div class="img-holder">
							<img src="/frontsite/images/post-space.png" alt="">
						</div>
						<p class="ease">Post a Space <br> For Rent</p>
					</a>
				</li>

				<li>
					<a href="#">
						<div class="noti-count ease">
							<p>16</p>
						</div>
						<div class="img-holder">
							<img src="/frontsite/images/post-space.png" alt="">
						</div>

						<p class="ease">Post a Space <br> For Rent</p>
					</a>
				</li>

			</ul>
		</div>

		<div class="clearfix">
			<div class=" listing-left">
				<div class="inner-title">
					<h3>Recent  Space/ Booth Posted <a href="#" class="f-right">SEE ALL</a></h3>
				</div>
				<ul class="db-listing">
					<li>
						<div class="content-holder">
							<h5><span>Category</span> Barber</h5>
							<a href="#">Space Booth for rent title goes here...</a>

							<p><span>Posted</span> Today10/26/20177</p>

						</div>
						<div class="content-holder renters">
							<p><span>50 </span> Renters Applied</p>
						</div>
						<div class="btn-holder">
							<a href="#" class="btn btn-blue-b btn-slim">See details</a>
						</div>
					</li>
					<li>
						<div class="content-holder">
							<h5><span>Category</span> Barber</h5>
							<a href="#">Space Booth for rent title goes here...</a>

							<p><span>Posted</span> Today10/26/20177</p>

						</div>
						<div class="content-holder renters">
							<p><span>50 </span> Renters Applied</p>
						</div>
						<div class="btn-holder">
							<a href="#" class="btn btn-blue-b btn-slim">See details</a>
						</div>
					</li>
					<li>
						<div class="content-holder">
							<h5><span>Category</span> Barber</h5>
							<a href="#">Space Booth for rent title goes here...</a>

							<p><span>Posted</span> Today10/26/20177</p>

						</div>
						<div class="content-holder renters">
							<p><span>50 </span> Renters Applied</p>
						</div>
						<div class="btn-holder">
							<a href="#" class="btn btn-blue-b btn-slim">See details</a>
						</div>
					</li>
					<li>
						<div class="content-holder">
							<h5><span>Category</span> Barber</h5>
							<a href="#">Space Booth for rent title goes here...</a>

							<p><span>Posted</span> Today10/26/20177</p>

						</div>
						<div class="content-holder renters">
							<p><span>50 </span> Renters Applied</p>
						</div>
						<div class="btn-holder">
							<a href="#" class="btn btn-blue-b btn-slim">See details</a>
						</div>
					</li>

				</ul>
				<div class="inner-title">
					<h3>Recent  Request for Nearby Help <a href="#" class="f-right">SEE ALL</a></h3>
				</div>
				<ul class="db-listing recent-jobs">
					<li>
						<div class="content-holder">
							<h5><span>professional Types </span> Barber, Hair Stylist,...</h5>
							<a href="#">Request Title Goes Right Here...</a>

							<p><span>Posted</span> Today10/26/20177</p>

						</div>
						<div class="content-holder renters">
							<p><span>50 </span> Professionals Applied</p>
						</div>
						<div class="btn-holder">
							<a href="#" class="btn btn-blue-b btn-slim">See details</a>
						</div>
					</li>
					<li>
						<div class="content-holder">
							<h5><span>professional Types </span> Barber, Hair Stylist,...</h5>
							<a href="#">Request Title Goes Right Here...</a>

							<p><span>Posted</span> Today10/26/20177</p>

						</div>
						<div class="content-holder renters">
							<p><span>50 </span> Professionals Applied</p>
						</div>
						<div class="btn-holder">
							<a href="#" class="btn btn-blue-b btn-slim">See details</a>
						</div>
					</li>
					<li>
						<div class="content-holder">
							<h5><span>professional Types </span> Barber, Hair Stylist,...</h5>
							<a href="#">Request Title Goes Right Here...</a>

							<p><span>Posted</span> Today10/26/20177</p>

						</div>
						<div class="content-holder renters">
							<p><span>50 </span> Professionals Applied</p>
						</div>
						<div class="btn-holder">
							<a href="#" class="btn btn-blue-b btn-slim">See details</a>
						</div>
					</li>
					<li>
						<div class="content-holder">
							<h5><span>professional Types </span> Barber, Hair Stylist,...</h5>
							<a href="#">Request Title Goes Right Here...</a>

							<p><span>Posted</span> Today10/26/20177</p>

						</div>
						<div class="content-holder renters">
							<p><span>50 </span> Professionals Applied</p>
						</div>
						<div class="btn-holder">
							<a href="#" class="btn btn-blue-b btn-slim">See details</a>
						</div>
					</li>
				</ul>
			</div>

		</div>
	</div>
</template>

<script>
	export default {

	}
</script>