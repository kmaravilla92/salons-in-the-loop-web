<template>
	<div class="content-container app-client-req-details app-req-listing help-req-listing booked-rental ownerhelp-req">
		<div class="inner-title">
			<h3>My Posted Rentals
			</h3>
		</div>
		<div class="request-details">
			<ul>
				<li>
					<div class="clearfix title-details">
						<div class="f-left">
							<p><span>Category </span>salon</p>
							<h3>Accusata complectitur at duo </h3>
							<label for=""><span>Posted</span> Today10/26/2017</label>
						</div>

						<div class="f-right rent">
							<p>Rent Rate</p>
							<h5>$100.00</h5>
						</div>
						<div class="f-right space">
							<p>Space Available </p>
							<h5>2/2</h5>
						</div>
					</div>
					<div class="content">
						<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. </p>
					</div>
					<div class="content-listing">
						<ul class="info">

							<li>
								<h5>Date available from </h5>
								<p><i class="fa fa-calendar" aria-hidden="true"></i> 10/26/2017</p>
							</li>
							<li>
								<h5>Date Availabe to</h5>
								<p><i class="fa fa-calendar" aria-hidden="true"></i> 10/27/2017</p>
							</li>
							<li>
								<h5>Schedule</h5>
								<p> Daily </p>
							</li>
							<li>
								<h5>Days</h5>
								<p>Sun  Mon  </p>
							</li>
							<li>
								<h5>Time Available to</h5>
								<p> <i class="fa fa-clock-o" aria-hidden="true"></i>  11:15 am</p>
							</li>
							<li>
								<h5>Time Availble to</h5>
								<p><i class="fa fa-clock-o" aria-hidden="true"></i> 6:00 pm</p>
							</li>
							<li>
								<h5>Address</h5>
								<p><i class="fa fa-map-marker" aria-hidden="true"></i>Complete address goes here,  Los Angeles, CA</p>
							</li>
						</ul>
						<div class="btn-holder">
							<div class="pro-applied">
								<label for="">50</label>
								<p>Renters Applied</p>
							</div>
							<a href="#" class="btn btn-blue">SEE DETAILS</a>
						</div>
					</div>
				</li>
				<li>
					<div class="clearfix title-details">
						<div class="f-left">
							<p><span>Category </span>salon</p>
							<h3>Accusata complectitur at duo </h3>
							<label for=""><span>Posted</span> Today10/26/2017</label>
						</div>

						<div class="f-right rent">
							<p>Rent Rate</p>
							<h5>$100.00</h5>
						</div>
						<div class="f-right space">
							<p>Space Available </p>
							<h5>2/2</h5>
						</div>
					</div>
					<div class="content">
						<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. </p>
					</div>
					<div class="content-listing">
						<ul class="info">

							<li>
								<h5>Date available from </h5>
								<p><i class="fa fa-calendar" aria-hidden="true"></i> 10/26/2017</p>
							</li>
							<li>
								<h5>Date Availabe to</h5>
								<p><i class="fa fa-calendar" aria-hidden="true"></i> 10/27/2017</p>
							</li>
							<li>
								<h5>Schedule</h5>
								<p> Daily </p>
							</li>
							<li>
								<h5>Days</h5>
								<p>Sun  Mon  </p>
							</li>
							<li>
								<h5>Time Available to</h5>
								<p> <i class="fa fa-clock-o" aria-hidden="true"></i>  11:15 am</p>
							</li>
							<li>
								<h5>Time Availble to</h5>
								<p><i class="fa fa-clock-o" aria-hidden="true"></i> 6:00 pm</p>
							</li>
							<li>
								<h5>Address</h5>
								<p><i class="fa fa-map-marker" aria-hidden="true"></i>Complete address goes here,  Los Angeles, CA</p>
							</li>
						</ul>
						<div class="btn-holder">
							<div class="pro-applied">
								<label for="">50</label>
								<p>Renters Applied</p>
							</div>
							<a href="#" class="btn btn-blue">SEE DETAILS</a>
						</div>
					</div>
				</li>
				<li>
					<div class="clearfix title-details">
						<div class="f-left">
							<p><span>Category </span>salon</p>
							<h3>Accusata complectitur at duo </h3>
							<label for=""><span>Posted</span> Today10/26/2017</label>
						</div>

						<div class="f-right rent">
							<p>Rent Rate</p>
							<h5>$100.00</h5>
						</div>
						<div class="f-right space">
							<p>Space Available </p>
							<h5>2/2</h5>
						</div>
					</div>
					<div class="content">
						<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. </p>
					</div>
					<div class="content-listing">
						<ul class="info">

							<li>
								<h5>Date available from </h5>
								<p><i class="fa fa-calendar" aria-hidden="true"></i> 10/26/2017</p>
							</li>
							<li>
								<h5>Date Availabe to</h5>
								<p><i class="fa fa-calendar" aria-hidden="true"></i> 10/27/2017</p>
							</li>
							<li>
								<h5>Schedule</h5>
								<p> Daily </p>
							</li>
							<li>
								<h5>Days</h5>
								<p>Sun  Mon  </p>
							</li>
							<li>
								<h5>Time Available to</h5>
								<p> <i class="fa fa-clock-o" aria-hidden="true"></i>  11:15 am</p>
							</li>
							<li>
								<h5>Time Availble to</h5>
								<p><i class="fa fa-clock-o" aria-hidden="true"></i> 6:00 pm</p>
							</li>
							<li>
								<h5>Address</h5>
								<p><i class="fa fa-map-marker" aria-hidden="true"></i>Complete address goes here,  Los Angeles, CA</p>
							</li>
						</ul>
						<div class="btn-holder">
							<div class="pro-applied">
								<label for="">50</label>
								<p>Renters Applied</p>
							</div>
							<a href="#" class="btn btn-blue">SEE DETAILS</a>
						</div>
					</div>
				</li>
				<li>
					<div class="clearfix title-details">
						<div class="f-left">
							<p><span>Category </span>salon</p>
							<h3>Accusata complectitur at duo </h3>
							<label for=""><span>Posted</span> Today10/26/2017</label>
						</div>

						<div class="f-right rent">
							<p>Rent Rate</p>
							<h5>$100.00</h5>
						</div>
						<div class="f-right space">
							<p>Space Available </p>
							<h5>2/2</h5>
						</div>
					</div>
					<div class="content">
						<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. </p>
					</div>
					<div class="content-listing">
						<ul class="info">

							<li>
								<h5>Date available from </h5>
								<p><i class="fa fa-calendar" aria-hidden="true"></i> 10/26/2017</p>
							</li>
							<li>
								<h5>Date Availabe to</h5>
								<p><i class="fa fa-calendar" aria-hidden="true"></i> 10/27/2017</p>
							</li>
							<li>
								<h5>Schedule</h5>
								<p> Daily </p>
							</li>
							<li>
								<h5>Days</h5>
								<p>Sun  Mon  </p>
							</li>
							<li>
								<h5>Time Available to</h5>
								<p> <i class="fa fa-clock-o" aria-hidden="true"></i>  11:15 am</p>
							</li>
							<li>
								<h5>Time Availble to</h5>
								<p><i class="fa fa-clock-o" aria-hidden="true"></i> 6:00 pm</p>
							</li>
							<li>
								<h5>Address</h5>
								<p><i class="fa fa-map-marker" aria-hidden="true"></i>Complete address goes here,  Los Angeles, CA</p>
							</li>
						</ul>
						<div class="btn-holder">
							<div class="pro-applied">
								<label for="">50</label>
								<p>Renters Applied</p>
							</div>
							<a href="#" class="btn btn-blue">SEE DETAILS</a>
						</div>
					</div>
				</li>


			</ul>
			<div class="pagination-holder clearfix">
				<div class="f-left">
					<p>Showing 8 out of 8 of My Posted Rentals</p>
				</div>
				<div class="pagination f-right">
					<a href="#">First</a>
					<a href="#">Previous</a>
					<a href="#">1</a>
					<a href="#">2</a>
					<a href="#">3</a>
					<a href="#">Next</a>
					<a href="#">Last</a>
				</div>
			</div>
		</div>
	</div>
</template>

<script>
	export default {}
</script>