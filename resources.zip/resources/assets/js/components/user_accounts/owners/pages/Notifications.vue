<template>
	<div class="content-container app-client-req-details help-req">
		<div class="inner-title">
			<h3>My Help Request Details</h3>
		</div>
		<div class="request-details">
				<div class="pro-details">
					<div class="pro-holder notif-holder">
						<div class="img-holder">
							<div class="img-over">
								<img src="/frontsite/images/pro1.jpg" alt="">
							</div>

						</div>
						<div class="information">
							<h3>Jessica Mathew</h3>
							<p>Square Town, Square City, Colorado - CO, 11010</p>
							<div class="rating">
								<i class="fa fa-star" aria-hidden="true"></i>
								<i class="fa fa-star" aria-hidden="true"></i>
								<i class="fa fa-star" aria-hidden="true"></i>
								<i class="fa fa-star" aria-hidden="true"></i>
								<i class="fa fa-star" aria-hidden="true"></i>
							</div>
						</div>
						<div class="description">
							<p><a href="#">Jesica Mathew</a> applied on your <a href="#">Space Booth for rent title goes here...</a> 2 hours ago</p>
						</div>
					</div>
					<div class="pro-holder notif-holder">
						<div class="img-holder">
							<div class="img-over">
								<img src="/frontsite/images/pro2.jpg" alt="">
							</div>

						</div>
						<div class="information">
							<h3>Jessica Mathew</h3>
							<p>Square Town, Square City, Colorado - CO, 11010</p>
							<div class="rating">
								<i class="fa fa-star" aria-hidden="true"></i>
								<i class="fa fa-star" aria-hidden="true"></i>
								<i class="fa fa-star" aria-hidden="true"></i>
								<i class="fa fa-star" aria-hidden="true"></i>
								<i class="fa fa-star" aria-hidden="true"></i>
							</div>
						</div>
						<div class="description">
							<p>Congratulations <a href="#">Jesica Mathew</a> successfully finished  your <a href="#">Space Booth for rent title goes here...</a> 1 week ago</p>
						</div>
					</div>
					<div class="pro-holder notif-holder">
						<div class="img-holder">
							<div class="img-over">
								<img src="/frontsite/images/pro3.jpg" alt="">
							</div>

						</div>
						<div class="information">
							<h3>Jessica Mathew</h3>
							<p>Square Town, Square City, Colorado - CO, 11010</p>
							<div class="rating">
								<i class="fa fa-star" aria-hidden="true"></i>
								<i class="fa fa-star" aria-hidden="true"></i>
								<i class="fa fa-star" aria-hidden="true"></i>
								<i class="fa fa-star" aria-hidden="true"></i>
								<i class="fa fa-star" aria-hidden="true"></i>
							</div>
						</div>
						<div class="description">
							<p><a href="#">Jesica Mathew</a> applied on your <a href="#">Space Booth for rent title goes here...</a> 2 hours ago</p>
						</div>
					</div>
					<div class="pro-holder notif-holder general-notif">
						<div class="img-holder">
							<div class="img-over">
								<img src="/frontsite/images/sitl-img.png" alt="">
							</div>
						</div>
						<div class="description">
							<h3>Congratulations!</h3>
							<p>You have successfully Registered 1 year ago. Lets Get Started and update your profile</p>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</template>

<script>
	export default {

	}
</script>