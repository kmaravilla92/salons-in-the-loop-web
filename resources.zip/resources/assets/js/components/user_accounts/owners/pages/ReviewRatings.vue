<template>
	<div class="content-container app-client-req-details  req-release review-rating">
		<div class="inner-title">
			<h3>Reviews and Ratings</h3>
		</div>
		<div class="request-details">
			<div class="clearfix title-details">
				<div class="f-left">
					<p><span>professional</span> Types Barber, Hair Stylist,...</p>
					<h3 class="salon-client-review">Accusata complectitur at duo </h3>
					<label for=""><span>Posted</span> Today10/26/2017</label>
				</div>
				<div class="f-right">
					<p>BUDGET</p>
					<h5>$100.00</h5>
				</div>
			</div>
			<div class="content">
				<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud.
				 </p>
				 <hr>
				 <div class="clearfix">
					 <div class="half-width f-left">

							<label for=""><i class="fa fa-newspaper-o" aria-hidden="true"></i></i>Category Name  </label> <br>
							<label for=""><i class="fa fa-calendar" aria-hidden="true"></i>  10/30/2016 6:00PM -12:00 PM </label> <br>
							<label for=""><i class="fa fa-map-marker" aria-hidden="true"></i> Los Angeles, CA</label>
						</div>
						<div class="half-width f-right">
						<div class="pro-holder">
							<div class="img-holder">
								<img src="/frontsite/images/pro1.jpg" alt="">
							</div>
							<div class="link-holder">
								<a href="#" class="btn btn-violet-light"><i class="fa fa-star" aria-hidden="true"></i> Write a review</a>
								<label>Service <br>
									Successfully Ended</label>
							</div>

						</div>
						</div>
				</div>

			</div>


		</div>
		<div class="request-details">
			<div class="clearfix title-details">
				<div class="f-left">
					<h3 class="salon-client-review">Accusata complectitur at duo </h3>
					<label for=""><span>Posted</span> Today10/26/2017</label>
				</div>
				<div class="f-right">
					<p>Budget</p>
					<h5>$100.00</h5>
				</div>
			</div>
			<div class="content">
				<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud.
				 </p>
				 <hr>
				 <label for=""><i class="fa fa-newspaper-o" aria-hidden="true"></i></i>Category Name  </label> <br>
					<label for=""><i class="fa fa-calendar" aria-hidden="true"></i>  10/30/2016 6:00PM -12:00 PM </label> <br>
					<label for=""><i class="fa fa-map-marker" aria-hidden="true"></i> Los Angeles, CA</label>
			</div>
			<div class="pro-details">


				<div class="pro-holder">
					<div class="img-holder">
						<div class="img-over">
							<img src="/frontsite/images/pro2.jpg" alt="">
						</div>

					</div>
					<div class="information">
						<div class="rating">
							<span>5.0</span>
							<p>OVERALL</p>
							<i class="fa fa-star" aria-hidden="true"></i>
							<i class="fa fa-star" aria-hidden="true"></i>
							<i class="fa fa-star" aria-hidden="true"></i>
							<i class="fa fa-star" aria-hidden="true"></i>
							<i class="fa fa-star" aria-hidden="true"></i>
						</div>
						<p>Reviewed 10/2/2016</p>

						<a href="#" class="btn btn-blue-b">Share my Review</a>
					</div>
					<div class="description">
						<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut Excepteur sint occaecat </p>
					</div>
				</div>

			</div>

		</div>
		<div class="request-details">
			<div class="clearfix title-details">
				<div class="f-left">
					<p><span>professional</span> Types Barber, Hair Stylist,...</p>
					<h3 class="salon-client-review">Accusata complectitur at duo </h3>
					<label for=""><span>Posted</span> Today10/26/2017</label>
				</div>
				<div class="f-right">
					<p>BUDGET</p>
					<h5>$100.00</h5>
				</div>
			</div>
			<div class="content">
				<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud.
				 </p>
				 <hr>
				 <div class="clearfix">
					 <div class="half-width f-left">

							<label for=""><i class="fa fa-newspaper-o" aria-hidden="true"></i></i>Category Name  </label> <br>
							<label for=""><i class="fa fa-calendar" aria-hidden="true"></i>  10/30/2016 6:00PM -12:00 PM </label> <br>
							<label for=""><i class="fa fa-map-marker" aria-hidden="true"></i> Los Angeles, CA</label>
						</div>
						<div class="half-width f-right">BUDGET
						<div class="pro-holder">
							<div class="img-holder">
								<img src="/frontsite/images/pro1.jpg" alt="">
							</div>
							<div class="link-holder">
								<a href="#" class="btn btn-violet-light"><i class="fa fa-star" aria-hidden="true"></i> Write a review</a>
								<label>Service <br>
									Successfully Ended</label>
							</div>
						</div>
						</div>
				</div>
			</div>


		</div>

		<div class="pagination-holder clearfix">
			<div class="f-left">
				<p>Showing 8 out of 8 of Reviews</p>
			</div>
			<div class="pagination f-right">
				<a href="#">First</a>
				<a href="#">Previous</a>
				<a href="#">1</a>
				<a href="#">2</a>
				<a href="#">3</a>
				<a href="#">Next</a>
				<a href="#">Last</a>
			</div>
		</div>

	</div>
</template>
<script>
	export default {
		mount() {
			
		}
	}
</script>