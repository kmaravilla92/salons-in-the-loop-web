<template>
	<div>
		<div class="calendar-container appointment-summary">
			<div class="title-container clearfix">
				<div class="img-holder">
					<img src="/frontsite/images/pro1.jpg" alt="">
				</div>
				<h3 class="col">Jessica Matthews</h3>
				<a href="#" class="f-right">back to <span>Jessica’s Profile</span></a>
			</div>
			<div class="form-holder clearfix">
				<h3>BOOKING SUMMARY
				<span class="f-right">June 29, 2017</span> </h3>
				<div class="content-container app-client-req-details client-appointment booking-details">
					<div class="request-details">
						<div class="services-holder">
							<ul>
								<li>
									<div class="services col">
										<p><i class="fa fa-scissors" aria-hidden="true"></i> Services</p>
									</div>
									<div class="notes col">
										<p><i class="fa fa-file-o" aria-hidden="true"></i> Additional Notes</p>
									</div>
									<div class="fee col">
										<p>Service Fee</p>
									</div>
								</li>
								<li>
									<div class="details-holder">
										<div class="services col">
											<h3>Hair Cut  <span>$100</span></h3>
											<p>$0 for 45 minutes </p>
										</div>
										<div class="notes col">
											<p>
												Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris
											</p>
										</div>
										<div class="fee col">
											<h3>$ 100</h3>
										</div>
									</div>
									<div class="details-holder">
										<div class="services col">
											<h3>Hair Cut  <span>$100</span></h3>
											<p>$0 for 45 minutes </p>
										</div>
										<div class="notes col">
											<p>
												Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris
											</p>
										</div>
										<div class="fee col">
											<h3>$ 100</h3>
										</div>
									</div>
									<div class="details-holder">
										<div class="services col">
											<h3>Hair Cut  <span>$100</span></h3>
											<p>$0 for 45 minutes </p>
										</div>
										<div class="notes col">
											<p>
												Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris
											</p>
										</div>
										<div class="fee col">
											<h3>$ 100</h3>
										</div>
									</div>
								</li>
								<li>
									<div class="time-location">
										<ul>
											<li class="clearfix">
												<h3 class="time f-left"><i class="fa fa-clock-o" aria-hidden="true"></i>Time</h3>
												<h3 class="loc f-right"><i class="fa fa-map-marker" aria-hidden="true"></i>Location</h3>
											</li>
											<li class="clearfix">
												<p class="time f-left">Morning <br> 7:30 - 8:00</p>
												<p class="loc f-right"><i class="fa fa-map-marker" aria-hidden="true"></i> Square town, Square city</p>
											</li>
											<li class="clearfix">
												<p class="time f-left">Morning <br> 7:30 - 8:00</p>
												<p class="loc f-right"><i class="fa fa-map-marker" aria-hidden="true"></i> Square town, Square city</p>
											</li>
											<li class="clearfix">
												<p class="time f-left">Morning <br> 7:30 - 8:00</p>
												<p class="loc f-right"><i class="fa fa-map-marker" aria-hidden="true"></i> Square town, Square city</p>
											</li>
										</ul>
										<div class="total">
											<h3>    Services(s) total time /booked time </h3>
											<h2>90 min / 90 min</h2>
										</div>
									</div>
								</li>
							</ul>
						</div>
					</div>
				</div>
			</div>
			<div class="btn-holder bottom-holder client-bg-dark">
				<div class="col tip">
					<a href="#" class="btn btn-blue">Add Tip</a>
				</div>

				<div class="f-right btn-hold">
					<input type="submit" class="btn btn-blue" value="Book Selected Service(s)">
					<p>See<a href="#"> Cancelation </a> and <a href="">Refund Policy.</a></p>
				</div>
				<div class="f-right col total">
					<p>Total Amount: <span>$300</span></p>

				</div>
			</div>
		</div>
	</div>
</template>

<script>
	export default {
		mounted() {
			
		},

		created() {
			
		},

		destroyed() {
			
		}
	}
</script>