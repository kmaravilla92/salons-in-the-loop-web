<template>
	<div class="content-container app-client-req-details app-req-listing">
    <div class="inner-title">
      <h3>Applied Clients’s Request


        <div class="sort-holder f-right">
          <a class="sort-link">Sort by  <i class="fa fa-chevron-down" aria-hidden="true"></i></a>
          <ul class="sort">
            <li><a href="#">All</a></li>
            <li><a href="#">Pending Jobs</a></li>
            <li><a href="#">Completed</a></li>
          </ul>
        </div>
      </h3>

    </div>
    <div class="request-details">
      <ul>
        <li>
          <div class="clearfix title-details">
            <div class="f-left">
              <p><span>User Types </span>Barber, Hair Stylist,...</p>
              <h3>Accusata complectitur at duo </h3>
              <label for=""><span>Posted</span> Today10/26/2017</label>
            </div>
            <div class="f-right">
              <p>Budget</p>
              <h5>$100.00</h5>
            </div>
          </div>
          <div class="content">
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. </p>
          </div>
          <div class="content-listing">
            <div class="info">
              <p><i class="fa fa-calendar" aria-hidden="true"></i> 10/26/2017</p>
              <p><i class="fa fa-clock-o" aria-hidden="true"></i>  11:15 pm</p>
              <p><i class="fa fa-map-marker" aria-hidden="true"></i>  Complete address goes here, Los Angeles, CA</p>
            </div>
            <div class="pro-applied">
              <label for="">50</label>
              <p> Professionals Applied</p>
            </div>
            <div class="btn-holder">
              <a href="#" class="btn btn-blue">SEE DETAILS</a>
            </div>
          </div>
        </li>
        <li>
          <div class="clearfix title-details">
            <div class="f-left">
              <p><span>User Types </span>Barber, Hair Stylist,...</p>
              <h3>Accusata complectitur at duo </h3>
              <label for=""><span>Posted</span> Today10/26/2017</label>
            </div>
            <div class="f-right">
              <p>Budget</p>
              <h5>$100.00</h5>
            </div>
          </div>
          <div class="content">
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. </p>
          </div>
          <div class="content-listing">
            <div class="info">
              <p><i class="fa fa-calendar" aria-hidden="true"></i> 10/26/2017</p>
              <p><i class="fa fa-clock-o" aria-hidden="true"></i>  11:15 pm</p>
              <p><i class="fa fa-map-marker" aria-hidden="true"></i>  Complete address goes here, Los Angeles, CA</p>
            </div>
            <div class="pro-applied">
              <label for="">50</label>
              <p> Professionals Applied</p>
            </div>
            <div class="btn-holder">
              <a href="#" class="btn btn-blue">SEE DETAILS</a>
            </div>
          </div>
        </li>
        <li>
          <div class="clearfix title-details">
            <div class="f-left">
              <p><span>User Types </span>Barber, Hair Stylist,...</p>
              <h3>Accusata complectitur at duo </h3>
              <label for=""><span>Posted</span> Today10/26/2017</label>
            </div>
            <div class="f-right">
              <p>Budget</p>
              <h5>$100.00</h5>
            </div>
          </div>
          <div class="content">
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. </p>
          </div>
          <div class="content-listing">
            <div class="info">
              <p><i class="fa fa-calendar" aria-hidden="true"></i> 10/26/2017</p>
              <p><i class="fa fa-clock-o" aria-hidden="true"></i>  11:15 pm</p>
              <p><i class="fa fa-map-marker" aria-hidden="true"></i>  Complete address goes here, Los Angeles, CA</p>
            </div>
            <div class="pro-applied">
              <label for="">50</label>
              <p> Professionals Applied</p>
            </div>
            <div class="btn-holder">
              <a href="#" class="btn btn-blue">SEE DETAILS</a>
            </div>
          </div>
        </li>
        <li>
          <div class="clearfix title-details">
            <div class="f-left">
              <p><span>User Types </span>Barber, Hair Stylist,...</p>
              <h3>Accusata complectitur at duo </h3>
              <label for=""><span>Posted</span> Today10/26/2017</label>
            </div>
            <div class="f-right">
              <p>Budget</p>
              <h5>$100.00</h5>
            </div>
          </div>
          <div class="content">
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. </p>
          </div>
          <div class="content-listing">
            <div class="info">
              <p><i class="fa fa-calendar" aria-hidden="true"></i> 10/26/2017</p>
              <p><i class="fa fa-clock-o" aria-hidden="true"></i>  11:15 pm</p>
              <p><i class="fa fa-map-marker" aria-hidden="true"></i>  Complete address goes here, Los Angeles, CA</p>
            </div>
            <div class="pro-applied">
              <label for="">50</label>
              <p> Professionals Applied</p>
            </div>
            <div class="btn-holder">
              <a href="#" class="btn btn-blue">SEE DETAILS</a>
            </div>
          </div>
        </li>
      </ul>
      <div class="pagination-holder clearfix">
        <div class="f-left">
          <p>Showing 8 out of 8 of Applied Client’s Request</p>
        </div>
        <div class="pagination f-right">
          <a href="#">First</a>
          <a href="#">Previous</a>
          <a href="#">1</a>
          <a href="#">2</a>
          <a href="#">3</a>
          <a href="#">Next</a>
          <a href="#">Last</a>
        </div>
      </div>

    </div>
  </div>
</template>

<script>
	export default {
    
	}
</script>