<template>
	<div class="content-container app-client-req-details">
		<div class="inner-title">
			<h3>My Posted Requests Details</h3>
		</div>
		<div class="request-details">
			<div class="clearfix title-details">
				<div class="f-left">
					<p><span>User Types </span>Barber, Hair Stylist,...</p>
					<h3>Accusata complectitur at duo </h3>
					<label for=""><span>Posted</span> Today10/26/2017</label>
				</div>
				<div class="f-right">
					<p>Budget</p>
					<h5>$100.00</h5>
				</div>
			</div>
			<div class="content">
				<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud
				exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
				 Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. </p>
				<label for=""><i class="fa fa-calendar" aria-hidden="true"></i> 10/26/2017</label>
				<label for=""><i class="fa fa-clock-o" aria-hidden="true"></i>  11:15 am   -   <i class="fa fa-clock-o" aria-hidden="true"></i>  12:00 pm       </label>
				<label for=""><i class="fa fa-map-marker" aria-hidden="true"></i>  Complete address goes here, Los Angeles, CA</label>
			</div>
			<div class="cancellation">
				<p>See <a href="#">Cancellation</a> and <a href="#">Refund Policy</a>.</p>
			</div>
			<div class="btn-holder write-review">

					<a href="#" class="btn btn-red-b">CANCEL SERVICE</a>


			</div>

			<div class="pro-details owner-pro-details">
				<div class="status">
					<span>50</span>
					<label for=""> Professionals Applied</label>
					<hr class="f-right">
				</div>

				<div class="pro-holder">
					<div class="img-holder">
						<div class="img-over">
							<img src="/frontsite/images/pro1.jpg" alt="">
						</div>
						<a href="#" class="btn btn-red-b">See Profile</a>
					</div>
					<div class="information help-req-owner">
						<h3>Jessica Mathew</h3>
						<p>Square Town, Square City, Colorado - CO, 11010</p>
						<div class="rating">
							<i class="fa fa-star" aria-hidden="true"></i>
							<i class="fa fa-star" aria-hidden="true"></i>
							<i class="fa fa-star" aria-hidden="true"></i>
							<i class="fa fa-star" aria-hidden="true"></i>
							<i class="fa fa-star" aria-hidden="true"></i>
						</div>

						<a href="#" class="btn btn-blue-b">Hire this Pro</a>
					</div>
					<div class="description">
						<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit .esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat </p>
					</div>
				</div>
				<div class="pro-holder">
					<div class="img-holder">
						<div class="img-over">
							<img src="/frontsite/images/pro2.jpg" alt="">
						</div>
						<a href="#" class="btn btn-red-b">See Profile</a>
					</div>
					<div class="information help-req-owner">
						<h3>Jessica Mathew</h3>
						<p>Square Town, Square City, Colorado - CO, 11010</p>
						<div class="rating">
							<i class="fa fa-star" aria-hidden="true"></i>
							<i class="fa fa-star" aria-hidden="true"></i>
							<i class="fa fa-star" aria-hidden="true"></i>
							<i class="fa fa-star" aria-hidden="true"></i>
							<i class="fa fa-star" aria-hidden="true"></i>
						</div>

						<a href="#" class="btn btn-blue-b">Hire this Pro</a>
					</div>
					<div class="description">
						<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit .esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat </p>
					</div>
				</div>
				<div class="pro-holder">
					<div class="img-holder">
						<div class="img-over">
							<img src="/frontsite/images/pro3.jpg" alt="">
						</div>
						<a href="#" class="btn btn-red-b">See Profile</a>
					</div>
					<div class="information help-req-owner">
						<h3>Jessica Mathew</h3>
						<p>Square Town, Square City, Colorado - CO, 11010</p>
						<div class="rating">
							<i class="fa fa-star" aria-hidden="true"></i>
							<i class="fa fa-star" aria-hidden="true"></i>
							<i class="fa fa-star" aria-hidden="true"></i>
							<i class="fa fa-star" aria-hidden="true"></i>
							<i class="fa fa-star" aria-hidden="true"></i>
						</div>

						<a href="#" class="btn btn-blue-b">Hire this Pro</a>
					</div>
					<div class="description">
						<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit .esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat </p>
					</div>
				</div>
				<div class="pro-holder">
					<div class="img-holder">
						<div class="img-over">
							<img src="/frontsite/images/pro1.jpg" alt="">
						</div>
						<a href="#" class="btn btn-red-b">See Profile</a>
					</div>
					<div class="information help-req-owner">
						<h3>Jessica Mathew</h3>
						<p>Square Town, Square City, Colorado - CO, 11010</p>
						<div class="rating">
							<i class="fa fa-star" aria-hidden="true"></i>
							<i class="fa fa-star" aria-hidden="true"></i>
							<i class="fa fa-star" aria-hidden="true"></i>
							<i class="fa fa-star" aria-hidden="true"></i>
							<i class="fa fa-star" aria-hidden="true"></i>
						</div>

						<a href="#" class="btn btn-blue-b">Hire this Pro</a>
					</div>
					<div class="description">
						<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit .esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat </p>
					</div>
				</div>

			</div>
			<br><br><br>
			<div class="pagination-holder clearfix">
				<div class="f-left">

				</div>
				<div class="pagination f-right">
					<a href="#">First</a>
					<a href="#">Previous</a>
					<a href="#">1</a>
					<a href="#">2</a>
					<a href="#">3</a>
					<a href="#">Next</a>
					<a href="#">Last</a>
				</div>
			</div>


		</div>
	</div>
</template>
<script>
	export default {
		
	}
</script>