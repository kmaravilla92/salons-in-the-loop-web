<template>
	<div class="content-container app-client-req-details">
    <div class="inner-title">
      <h3>Client Request Applied Details</h3>
    </div>
    <div class="request-details">
      <div class="clearfix title-details">
        <div class="f-left">
          <p><span>User Types </span>Barber, Hair Stylist,...</p>
          <h3>Accusata complectitur at duo </h3>
          <label for=""><span>Posted</span> Today10/26/2017</label>
        </div>
        <div class="f-right">
          <p>Budget</p>
          <h5>$100.00</h5>
        </div>
      </div>
      <div class="content">
        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud
        exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
         Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. </p>
        <label for=""><i class="fa fa-calendar" aria-hidden="true"></i> 10/26/2017</label>
        <label for=""><i class="fa fa-clock-o" aria-hidden="true"></i>  11:15 am   -   <i class="fa fa-clock-o" aria-hidden="true"></i>  12:00 pm       </label>
        <label for=""><i class="fa fa-map-marker" aria-hidden="true"></i>  Complete address goes here, Los Angeles, CA</label>
      </div>
      <div class="pro-details">
        <div class="status">
          <i class="fa fa-check" aria-hidden="true"></i>
          <label for="">Hired</label>
          <hr class="f-right">
        </div>

        <div class="pro-holder">
          <div class="img-holder">
            <div class="img-over">
              <img src="/frontsite/images/pro2.jpg" alt="">
            </div>
            <a href="#" class="btn btn-red-b">See Profile</a>
          </div>
          <div class="information">
            <h3>Jessica Mathew</h3>
            <p>Square Town, Square City, Colorado - CO, 11010</p>
            <div class="rating">
              <i class="fa fa-star" aria-hidden="true"></i>
              <i class="fa fa-star" aria-hidden="true"></i>
              <i class="fa fa-star" aria-hidden="true"></i>
              <i class="fa fa-star" aria-hidden="true"></i>
              <i class="fa fa-star" aria-hidden="true"></i>
            </div>
          </div>
          <div class="description">
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit .esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat </p>
          </div>
        </div>
        <div class="payment">
          <ul>
            <li class="clearfix">
              <p class="f-left">Amount</p>
              <p class="f-right">Status</p>
            </li>
            <li class="clearfix">
              <p class="f-left">$10.00</p>
              <p class="f-right"><span>Released</span></p>
            </li>
            <li class="clearfix">
              <p class="f-left">$90.00</p>
              <p class="f-right">Not yet released</p>
            </li>
          </ul>
          <p class="total">Total: $100.00</p>
        </div>
      </div>
      <div class="btn-holder write-review">
          <a href="#" class="btn btn-red-b">WRITE REVIEW</a>
      </div>

    </div>
  </div>
</template>

<script>
	export default {
    
	}
</script>