<template>
	<div class="content-container app-client-req-details help-req search-client-req-details">
		<div class="client-req-holder">
			<Loader
				v-if="is_loading"
				text="LOADING POSTED REQUESTS ..."
			>	
			</Loader>
			<div v-if="!is_loading">
				<div class="client-details">
					<div class="img-holder">
						<img src="/frontsite/images/client1-big.jpg" alt="">
					</div>
					<h3>Alexa Snowe</h3>
					<a href="#" class="btn btn-red-b">See Profile</a>
				</div>
				<div class="request-details">
					<div class="clearfix title-details">
						<div class="f-left">
							<p><span>User Types </span>{{ posted_request.professional_types }}</p>
							<h3>{{ posted_request.title }} </h3>
							<label for=""><span>Posted</span> {{posted_request.created_at }}</label>
						</div>
						<div class="f-right">
							<p>Budget</p>
							<h5>$ {{ posted_request.budget }}</h5>
						</div>
					</div>
					<div class="content">
						<p>{{ posted_request.message }}</p>
					</div>
					<div class="sched-requirement">
						<div class="schedule">
							<ul>
								<li>
									<h5>Schedule</h5>
									<p>Daily</p>
								</li>
								<li>
									<h5>Days</h5>
									<p>Sun Mon</p>
								</li>
								<li>
									<h5>Desired Start Date</h5>
									<p><i class="fa fa-calendar" aria-hidden="true"></i> {{ posted_request.desired_date }}</p>
								</li>
								<li>
									<h5>Desired End Date</h5>
									<p><i class="fa fa-calendar" aria-hidden="true"></i> {{ posted_request.desired_date }}</p>
								</li>
								<li>
									<h5>Desired Start Time</h5>
									<p> <i class="fa fa-clock-o" aria-hidden="true"></i> {{ posted_request.desired_time }}</p>
								</li>
								<li>
									<h5>Desired End Time</h5>
									<p> <i class="fa fa-clock-o" aria-hidden="true"></i>  {{ posted_request.desired_time }}</p>
								</li>
								<li>
									<h5>Address</h5>
									<p><i class="fa fa-map-marker" aria-hidden="true"></i>  Complete address goes here, Los Angeles, CA</p>
								</li>
							</ul>
						</div>
							<div class="requirements">
								<h3>Requirements</h3>
								<ul>
									<li>Must perform service in salon</li>
									<li>No partial payment fir this listing</li>
									<li>Must be licesed</li>
								</ul>
							</div>
						</div>
						<div class="img-listing">
							<div class="img-title">
								<h3>My Current Look</h3>
							</div>

							<a 
								v-for="current_look_photo in posted_request.current_look_photos"
								:href="current_look_photo" 
								class="img-holder">
								<img 
									:src="current_look_photo" 
									:alt="current_look_photo">
							</a>


						</div>
						<div class="img-listing">
							<div class="img-title">
								<h3>My Desired Look</h3>
							</div>

							<a 
								v-for="current_look_photo in posted_request.desired_look_photos"
								:href="current_look_photo" 
								class="img-holder">
								<img 
									:src="current_look_photo" 
									:alt="current_look_photo">
							</a>
						</div>
				</div>
				<div class="btn-holder">
					<a href="#" class="btn btn-blue">APPLY FOR THIS SERVICE</a>
				</div>
			</div>
		</div>
	</div>
</template>

<script>
	export default {
		data() {
			return {
				is_loading: true,
				posted_request: []
			}
		},

		mounted() {
			$('#main-wrapper').addClass('client-req');

			this.$parent.sidebar.show = false;
			this.$parent.in_user_dashboard = false;
			$('.pro-bg.cprs').show();
		},

		destroyed() {
			$('#main-wrapper').removeClass('client-req');
			this.$parent.sidebar.show = true;
			this.$parent.in_user_dashboard = true;
			$('.pro-bg.cprs').hide();
		},
		
		created() {
			this.$parent.sidebar.show = false;
			this.$parent.in_user_dashboard = false;
			$('.pro-bg.cprs').show();

			this.fetchData();
		},

		watch: {
			'$route': 'fetchData'
		},

		methods: {
			fetchData() {
				var vm = this;
					axios
						.get(apiBaseUrl + 'rest/posted-requests/' + this.$route.params.id )
						.then(function(response){
							vm.posted_request = response.data;
							vm.is_loading = false;
						}).catch(function(){
							vm.is_loading = false;
						});
			}
		}
	}
</script>